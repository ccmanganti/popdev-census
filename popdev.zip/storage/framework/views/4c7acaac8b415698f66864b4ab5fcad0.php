<?php if(filled($brand = config('filament.brand'))): ?>
    <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'filament-brand text-xl font-bold tracking-tight',
        'dark:text-white' => config('filament.dark_mode'),
    ]) ?>">
    <img src="<?php echo e(asset('img/logo_header.png')); ?>" alt="Logo" class="h-10">
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\deployment\popdev\vendor\filament\filament\src\/../resources/views/components/brand.blade.php ENDPATH**/ ?>