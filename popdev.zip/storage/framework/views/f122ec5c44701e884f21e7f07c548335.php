<?php
    $chartId = $this->getChartId();
    $heading = $this->getHeading();
    $pollingInterval = $this->getPollingInterval();
    $contentHeight = $this->getContentHeight();
    $filters = $this->getFilters();
    $indicatorsCount = $this->indicatorsCount();
    $filterForm = $this->form;
    $readyToLoad = $this->readyToLoad;
    $getCachedOptions = $this->getCachedOptions();
    $filterFormAccessible = $this->getFilterFormAccessible();
    $loadingIndicator = $this->getLoadingIndicator();
    $footer = $this->getFooter();
    $deferLoading = $this->getDeferLoading();
    $darkModeEnabled = $this->getDarkMode();
?>

<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.widget','data' => ['class' => 'filament-widgets-chart-widget']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'filament-widgets-chart-widget']); ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.card.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

        <?php if (isset($component)) { $__componentOriginal8017bf7f56163546e63e9638005869dd = $component; } ?>
<?php $component = Leandrocfe\FilamentApexCharts\Components\WidgetContent::resolve(['chartId' => $chartId,'pollingInterval' => $pollingInterval,'deferLoading' => $deferLoading] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-apex-charts::widget-content'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Leandrocfe\FilamentApexCharts\Components\WidgetContent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

            <?php if($heading || $filters || $filterForm): ?>
                <?php if (isset($component)) { $__componentOriginald9d230b37b44dbcd5ca3c381b79c72e4 = $component; } ?>
<?php $component = Leandrocfe\FilamentApexCharts\Components\Header::resolve(['heading' => $heading,'filters' => $filters,'filterForm' => ''.e($filterFormAccessible ? $filterForm : null).'','indicatorsCount' => $indicatorsCount] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-apex-charts::header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Leandrocfe\FilamentApexCharts\Components\Header::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9d230b37b44dbcd5ca3c381b79c72e4)): ?>
<?php $component = $__componentOriginald9d230b37b44dbcd5ca3c381b79c72e4; ?>
<?php unset($__componentOriginald9d230b37b44dbcd5ca3c381b79c72e4); ?>
<?php endif; ?>
            <?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal42f04f3b4393322830ce3f497dfbcde9 = $component; } ?>
<?php $component = Leandrocfe\FilamentApexCharts\Components\Chart::resolve(['chartId' => $chartId,'contentHeight' => $contentHeight,'pollingInterval' => $pollingInterval,'readyToLoad' => $readyToLoad,'getCachedOptions' => $getCachedOptions,'loadingIndicator' => $loadingIndicator,'darkModeEnabled' => $darkModeEnabled] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-apex-charts::chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Leandrocfe\FilamentApexCharts\Components\Chart::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42f04f3b4393322830ce3f497dfbcde9)): ?>
<?php $component = $__componentOriginal42f04f3b4393322830ce3f497dfbcde9; ?>
<?php unset($__componentOriginal42f04f3b4393322830ce3f497dfbcde9); ?>
<?php endif; ?>

            <?php if($footer): ?>
                <div class="relative">
                    <?php echo $footer; ?>

                </div>
            <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8017bf7f56163546e63e9638005869dd)): ?>
<?php $component = $__componentOriginal8017bf7f56163546e63e9638005869dd; ?>
<?php unset($__componentOriginal8017bf7f56163546e63e9638005869dd); ?>
<?php endif; ?>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\deployment\popdev\vendor\leandrocfe\filament-apex-charts\src\/../resources/views/widgets/apex-chart-widget.blade.php ENDPATH**/ ?>