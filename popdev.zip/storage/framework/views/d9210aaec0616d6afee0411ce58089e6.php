<div <?php echo $deferLoading ? ' wire:init="loadWidget" ' : ''; ?> @apex-charts-dropdown-close.window="dropdownOpen = false" x-data="{ dropdownOpen: false, pollingInterval: '<?php echo e($pollingInterval); ?>' }"
    x-init="$watch('dropdownOpen', function(value) {
    
        let chartElement = document.getElementById('<?php echo e($chartId); ?>')
    
        if (pollingInterval) {
    
            if (value) {
                chartElement.removeAttribute('wire:poll.' + pollingInterval)
            } else {
                chartElement.setAttribute('wire:poll.' + pollingInterval, 'updateChartOptions')
            }
        }
    
    })">

    <?php echo e($slot); ?>


</div>
<?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\deployment\popdev\vendor\leandrocfe\filament-apex-charts\src\/../resources/views/widgets/components/widget-content.blade.php ENDPATH**/ ?>