<div class="flex items-center justify-center" style="<?php echo e($contentHeight ? 'height: ' . $contentHeight . 'px;' : ''); ?>">
    <?php if($readyToLoad): ?>
        <div <?php echo $pollingInterval ? 'wire:poll.' . $pollingInterval . '="updateChartOptions"' : ''; ?> class="w-full" id="<?php echo e($chartId); ?>" x-data="{
            chart: null,
            darkModeEnabled: <?php echo e($darkModeEnabled ? 'true' : 'false'); ?>,
            mode: localStorage.getItem('theme'),
            init: function() {
                let chart = this.initChart()
        
                $wire.on('updateChartOptions', async ({ options }) => {
        
                    if (this.darkModeEnabled) {
                        options.theme.mode = this.mode
                    }
        
                    this.chart.updateOptions(options)
        
                })
                $wire.on('filterChartData', async ({ options }) => {
                    this.chart.updateOptions(options)
                })
            },
            initChart: function(options = null) {
        
                options = options ?? <?php echo \Illuminate\Support\Js::from($getCachedOptions)->toHtml() ?>
        
                if (this.darkModeEnabled) {
                    options.theme.mode = this.mode
                }
        
                this.chart = new ApexCharts(document.querySelector('#<?php echo e($chartId); ?>'), options)
        
                return this.chart.render()
            },
        }"
            x-on:dark-mode-toggled.window="mode = $event.detail" x-init="$watch('mode', () => {
                window.livewire.find('<?php echo e($_instance->id); ?>').updateChartOptions();
            })" wire:ignore>

        </div>
    <?php else: ?>
        <div class="m-auto">
            <?php if($loadingIndicator): ?>
                <?php echo $loadingIndicator; ?>

            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-support::components.loading-indicator','data' => ['xCloak' => true,'wire:loading.delay' => true,'class' => 'w-7 h-7']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-support::loading-indicator'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-cloak' => true,'wire:loading.delay' => true,'class' => 'w-7 h-7']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\deployment\popdev\vendor\leandrocfe\filament-apex-charts\src\/../resources/views/widgets/components/chart.blade.php ENDPATH**/ ?>