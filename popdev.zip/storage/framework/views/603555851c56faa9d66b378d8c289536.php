<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-ui-spotlight')->html();
} elseif ($_instance->childHasBeenRendered('0xdnwR9')) {
    $componentId = $_instance->getRenderedChildComponentId('0xdnwR9');
    $componentTag = $_instance->getRenderedChildComponentTagName('0xdnwR9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0xdnwR9');
} else {
    $response = \Livewire\Livewire::mount('livewire-ui-spotlight');
    $html = $response->html();
    $_instance->logRenderedChild('0xdnwR9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\Users\lenovo\Documents\LinkMaster\Personal Files\Programming Projects\Popdev\deployment\popdev\storage\framework\views/29f10b3a3ae1f582e26d0c78ff3a3419.blade.php ENDPATH**/ ?>